"""
Decoders
========

This is an example for decoding.
"""

#%%
# First, we will do some setup that won't be required on your system.
import sys, os
print(os.getcwd())
sys.path.append('../../')

#import mvpy as mv